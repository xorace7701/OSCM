-- ====================================================================
--               OSCM — Sovereign Appliance Database Seeding
--                    Initial Provisioning Core Data v1.1
-- ====================================================================

-- Populate standard network endpoints for initial appliance validation runs
INSERT OR IGNORE INTO directory (contact_name, extension_number, display_group) VALUES 
('OSCM Provisioner Server', '100', 'OSCM Systems'),
('VLAN 100 Gateway App', '900', 'OSCM Gateways'),
('Multicast Intercom Group', '800', 'OSCM Intercom');
