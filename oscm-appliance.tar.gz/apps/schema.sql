-- OSCM Platform v1.0 - Core Database Schema
-- Target Engine: SQLite3

PRAGMA foreign_keys = ON;

-- 1. ASSET CONTROL MATRIX
CREATE TABLE IF NOT EXISTS assets (
    mac_address TEXT PRIMARY KEY CHECK(length(mac_address) = 12),
    hardware_model TEXT NOT NULL,          -- e.g., 'SPA525G2', 'SPA962', 'SPA3102'
    vlan_id INTEGER NOT NULL CHECK(vlan_id IN (1, 2, 100)),
    engine_mode INTEGER NOT NULL CHECK(engine_mode IN (1, 2)), -- 1 = Cisco XML, 2 = Open SIP
    assigned_extension TEXT unique,
    developer_mode_unlocked INTEGER DEFAULT 1 CHECK(developer_mode_unlocked IN (0, 1)),
    last_sync_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. UNIFIED XML PHONEBOOK DIRECTORY
CREATE TABLE IF NOT EXISTS directory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contact_name TEXT NOT NULL,
    extension_number TEXT NOT NULL UNIQUE,
    display_group TEXT DEFAULT 'OSCM Internal'
);

-- 3. SIDECAR & HARDWARE KEY MAPPING (BLF/Speed Dial strings)
CREATE TABLE IF NOT EXISTS hardware_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mac_address TEXT NOT NULL,
    key_number INTEGER NOT NULL CHECK(key_number > 0),
    function_string TEXT NOT NULL,         -- e.g., 'fnc=blf+sd;sub=101@192.168.1.254'
    FOREIGN KEY(mac_address) REFERENCES assets(mac_address) ON DELETE CASCADE,
    UNIQUE(mac_address, key_number)
);

-- 4. MEDIA & CUSTOMIZATION REGISTRY (Wallpapers / Ringtones)
CREATE TABLE IF NOT EXISTS peripheral_media (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mac_address TEXT NOT NULL,
    wallpaper_filename TEXT DEFAULT 'default.png',
    ringtone_filename TEXT DEFAULT 'ringlist.xml',
    camera_stream_url TEXT DEFAULT NULL,   -- Injected MJPEG URL
    FOREIGN KEY(mac_address) REFERENCES assets(mac_address) ON DELETE CASCADE
);

-- SEED DATA: Populate standard network endpoints for initial validation
INSERT OR IGNORE INTO directory (contact_name, extension_number) VALUES 
('OSCM Provisioner Server', '100'),
('VLAN 100 Gateway App', '900'),
('Multicast Intercom Group', '800');
